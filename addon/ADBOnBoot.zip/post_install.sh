#!/sbin/sh
for file in /system/system/build.prop /vendor/build.prop /system/vendor/build.prop; do
    if [ -f "$file" ]; then
        sed -i "s%ro.adb.secure=.*%%g" "$file"
        sed -i "s%ro.secure=.*%%g" "$file"
        sed -i "s%ro.debuggable=.*%%g" "$file"
        sed -i "s%persist.service.debuggable=.*%%g" "$file"
        sed -i "s%persist.service.adb.enable=.*%%g" "$file"
        sed -i "s%persist.sys.usb.config=.*%%g" "$file"
    fi
done

#default.prop
for file in /system/system/etc/prop.default /system/default.prop; do
    if [ -f "$file" ]; then
        if grep -Fq "ro.adb.secure=" "$file"; then
            sed -i "s%ro.adb.secure=.*%ro.adb.secure=0%" "$file"
        else
            echo "ro.adb.secure=0" >> "$file"
        fi

        if grep -Fq "ro.secure=" "$file"; then
            sed -i "s%ro.secure=.*%ro.secure=0%" "$file"
        else
            echo "ro.secure=0" >> "$file"
        fi

        if grep -Fq "ro.debuggable=" "$file"; then
            sed -i "s%ro.debuggable=.*%ro.debuggable=1%" "$file"
        else
            echo "ro.debuggable=1" >> "$file"
        fi

        if grep -Fq "persist.service.debuggable=" "$file"; then
            sed -i "s%persist.service.debuggable=.*%persist.service.debuggable=1%" "$file"
        else
            echo "persist.service.debuggable=1" >> "$file"
        fi

        if grep -Fq "persist.service.adb.enable=" "$file"; then
            sed -i "s%persist.service.adb.enable=.*%persist.service.adb.enable=1%" "$file"
        else
            echo "persist.service.adb.enable=1" >> "$file"
        fi

        if grep -Fq "persist.sys.usb.config=" "$file"; then
            sed -i "s%persist.sys.usb.config=.*%persist.sys.usb.config=adb%" "$file"
        else
            echo "persist.sys.usb.config=adb" >> "$file"
        fi
    fi
done
